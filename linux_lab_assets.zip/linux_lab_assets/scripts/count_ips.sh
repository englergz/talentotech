#!/usr/bin/env bash
# Cuenta las IPs más frecuentes en logs/syslog_sample.log
LOG="logs/syslog_sample.log"
if [ ! -f "$LOG" ]; then
  echo "No se encontró $LOG. Ejecuta este script desde la carpeta linux_lab_assets."
  exit 1
fi
grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}' "$LOG" | sort | uniq -c | sort -nr | head -5

#!/usr/bin/env bash
echo "Hola Talento Tech 🚀"
echo "Usuario actual: $(whoami)"
echo "Directorio: $(pwd)"

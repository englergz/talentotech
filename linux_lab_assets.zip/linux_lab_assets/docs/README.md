
# linux_lab_assets
Material de apoyo para el Laboratorio de Fundamentos de Linux (1h).

## Estructura
- `data/` – datos de ejemplo (`names.txt`, `sales.csv`)
- `logs/` – `syslog_sample.log` para practicar `grep`, `tail -f`, etc.
- `scripts/` – `hello.sh` y `count_ips.sh`
- `playground/` – archivos seguros para probar `cp/mv/rm`
- `docs/` – `cheat_sheet.md`

## Ejercicios rápidos
1) Ejecutar script:
```
chmod +x scripts/hello.sh
./scripts/hello.sh
```
2) Top 5 IPs en el syslog:
```
chmod +x scripts/count_ips.sh
./scripts/count_ips.sh
```
3) Buscar errores en logs:
```
grep -n "ERROR" logs/syslog_sample.log | head
```

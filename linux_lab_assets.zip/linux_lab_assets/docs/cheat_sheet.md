
# Linux Cheat Sheet (básico)
- `pwd` – muestra el directorio actual.
- `ls -la` – lista con detalles, incluidos ocultos.
- `cd RUTA` – cambia de directorio (usa `cd ..` para subir).
- `mkdir NOMBRE` – crea carpeta. `mkdir -p a/b/c` anida.
- `touch archivo.txt` – crea archivo vacío.
- `cp origen destino` – copia. `-r` recursivo (carpetas).
- `mv origen destino` – mueve/renombra.
- `rm archivo` – elimina. `rm -r carpeta` borra recursivo.
- `cat`, `less`, `head`, `tail -f` – ver archivos.
- `grep "patrón" archivo` – busca texto.
- Pipes `|` y redirecciones `>`, `>>`.
- `chmod +x script.sh` – vuelve ejecutable.
- `ps aux | grep nombre` – ver procesos.
- `top` – monitoreo en vivo.
- `apt update && apt install paquete` – instalar software (Ubuntu).
